
import React from 'react';
import { Star } from 'lucide-react';

const SocialProof: React.FC = () => {
  const logos = [
    'https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg',
    'https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg',
    'https://upload.wikimedia.org/wikipedia/commons/0/08/Netflix_2015_logo.svg',
    'https://upload.wikimedia.org/wikipedia/commons/b/b9/Slack_Technologies_Logo.svg',
    'https://upload.wikimedia.org/wikipedia/commons/c/ce/Coca-Cola_logo.svg'
  ];

  return (
    <section className="bg-white py-16 border-y border-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-16">
          <div className="flex flex-col items-center md:items-start text-center md:text-left gap-3">
            <div className="flex gap-1 text-orange-400">
              {[...Array(5)].map((_, i) => <Star key={i} size={22} fill="currentColor" />)}
            </div>
            <p className="text-lg font-black text-slate-900 tracking-tight tracking-tighter">4.9/5 RATING GLOBAL</p>
            <p className="text-xs text-orange-600 font-black uppercase tracking-[0.2em]">+COP $24B FACTURADOS EN 2024</p>
          </div>

          <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20">
            {logos.map((logo, idx) => (
              <img 
                key={idx} 
                src={logo} 
                alt="Client Logo" 
                className="h-6 md:h-10 opacity-30 hover:opacity-100 transition-all grayscale hover:grayscale-0 cursor-pointer hover:scale-110"
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialProof;
