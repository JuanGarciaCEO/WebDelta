
import React from 'react';
import { BarChart3, Users, TrendingUp, Shield, Rocket, Target } from 'lucide-react';

const Benefits: React.FC = () => {
  const benefits = [
    {
      icon: <Target className="text-orange-600" size={28} />,
      title: "Targeting de Alta Calidad",
      description: "Llegamos al 1% de consumidores con mayor poder adquisitivo en Bogotá, Medellín y Cali."
    },
    {
      icon: <TrendingUp className="text-orange-600" size={28} />,
      title: "Escala Predictiva",
      description: "Modelos matemáticos que proyectan el crecimiento antes de invertir un solo peso."
    },
    {
      icon: <Rocket className="text-orange-600" size={28} />,
      title: "Lanzamiento en 48h",
      description: "Nuestra infraestructura nos permite iterar creativos y audiencias a una velocidad imbatible."
    },
    {
      icon: <Shield className="text-orange-600" size={28} />,
      title: "Transparencia Total",
      description: "Acceso ilimitado a tus cuentas publicitarias. Eres dueño de tus datos y tus activos."
    }
  ];

  return (
    <section id="beneficios" className="py-32 bg-[#fffaf5] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h3 className="text-sm font-black text-orange-600 uppercase tracking-[0.4em] mb-6">Nuestra Metodología</h3>
          <h2 className="text-4xl md:text-7xl font-black text-slate-900 tracking-tighter leading-tight">
            Diseñamos el motor que impulsa <br className="hidden md:block"/> marcas imparables.
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, idx) => (
            <div key={idx} className="p-10 rounded-[3rem] bg-white border border-orange-50 hover:border-orange-200 hover:shadow-[0_30px_60px_-15px_rgba(234,88,12,0.1)] transition-all group relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-full translate-x-1/2 -translate-y-1/2 -z-10 transition-transform group-hover:scale-110"></div>
              <div className="w-16 h-16 rounded-3xl bg-orange-50 flex items-center justify-center mb-8 group-hover:bg-orange-600 group-hover:text-white transition-all duration-500 shadow-sm">
                {benefit.icon}
              </div>
              <h4 className="text-2xl font-black text-slate-900 mb-4 tracking-tight">{benefit.title}</h4>
              <p className="text-slate-500 leading-relaxed font-medium">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
