
import React from 'react';
import { ShieldCheck, ArrowRight, Zap, TrendingUp, Star } from 'lucide-react';

const OfferSection: React.FC = () => {
  return (
    <section id="oferta" className="py-32 bg-[#2d1b0d] text-white relative overflow-hidden">
      {/* Warm Glow Backgrounds */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-orange-600 rounded-full blur-[150px] opacity-20 -translate-y-1/2 translate-x-1/2"></div>
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-amber-600 rounded-full blur-[120px] opacity-10 translate-y-1/2 -translate-x-1/2"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div>
            <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-orange-500/10 text-orange-400 text-xs font-black uppercase tracking-[0.2em] mb-10 border border-orange-500/20 shadow-2xl">
              <Zap size={16} /> CLIENTES EXCLUSIVOS COLOMBIA
            </div>
            <h2 className="text-5xl md:text-7xl font-black mb-10 tracking-tighter leading-[0.9]">
              Garantía Delta: <br/>
              <span className="text-orange-500 italic">3x ROI o es gratis.</span>
            </h2>
            <p className="text-xl text-orange-100/60 mb-12 leading-relaxed font-medium">
              Eliminamos el riesgo por completo. No te vendemos promesas de "branding" vacío; te garantizamos un retorno de inversión real firmado por contrato. Si no triplicamos tu pauta en 90 días, trabajamos gratis para ti.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-8 mb-16">
              <div className="p-8 rounded-[2.5rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
                <ShieldCheck className="text-orange-400 mb-4" size={32} />
                <h4 className="font-bold text-lg mb-2 tracking-tight">Cero Riesgo</h4>
                <p className="text-orange-100/40 text-sm leading-relaxed">Solo cobramos honorarios si los resultados superan el 3x ROI inicial.</p>
              </div>
              <div className="p-8 rounded-[2.5rem] bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">
                <TrendingUp className="text-orange-400 mb-4" size={32} />
                <h4 className="font-bold text-lg mb-2 tracking-tight">Escala Agresiva</h4>
                <p className="text-orange-100/40 text-sm leading-relaxed">Nuestras estrategias están diseñadas para escalar facturación, no solo tráfico.</p>
              </div>
            </div>
          </div>

          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-orange-600 to-amber-600 rounded-[3.5rem] blur opacity-30 group-hover:opacity-60 transition-opacity"></div>
            <div className="relative p-12 md:p-16 rounded-[3.5rem] bg-white/5 backdrop-blur-3xl border border-white/10 text-center shadow-2xl overflow-hidden">
              <div className="absolute top-4 right-4 text-orange-500/20">
                 <Star size={100} fill="currentColor" stroke="none" />
              </div>
              <h3 className="text-4xl font-black mb-8 italic tracking-tight">"Invertir en Delta fue la mejor decisión comercial."</h3>
              <p className="text-orange-100/70 text-lg mb-12 leading-relaxed font-medium italic">
                "Crecimos nuestra marca de e-commerce de 10M a 120M mensuales en el primer trimestre. No solo cumplen la garantía, la superan."
              </p>
              <div className="flex flex-col items-center gap-4">
                <div className="w-20 h-20 rounded-full border-4 border-orange-500/30 overflow-hidden shadow-2xl">
                   <img src="https://i.pravatar.cc/150?u=alejandrog" alt="Testimonial" />
                </div>
                <div>
                  <p className="font-black text-xl">Andrés Mendoza</p>
                  <p className="text-orange-500 text-xs font-black uppercase tracking-widest">Founder de ZenLife Colombia</p>
                </div>
              </div>
              <button 
                onClick={() => document.getElementById('agendar')?.scrollIntoView({behavior: 'smooth'})}
                className="mt-12 w-full py-6 bg-orange-600 text-white rounded-[2rem] font-black text-2xl hover:bg-orange-700 transition-all shadow-2xl shadow-orange-600/30 flex items-center justify-center gap-3 active:scale-95 group"
              >
                SOLICITAR MI ROI 3X <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default OfferSection;
