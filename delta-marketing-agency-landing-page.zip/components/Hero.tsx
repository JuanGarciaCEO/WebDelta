
import React, { useEffect, useState } from 'react';
import { Play, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

const Hero: React.FC = () => {
  const [particles, setParticles] = useState<any[]>([]);

  useEffect(() => {
    // Generate random particles for background animation
    const newParticles = Array.from({ length: 25 }).map((_, i) => ({
      id: i,
      size: Math.random() * 4 + 2,
      left: `${Math.random() * 100}%`,
      top: `${Math.random() * 100}%`,
      duration: `${Math.random() * 10 + 5}s`,
      delay: `${Math.random() * 5}s`
    }));
    setParticles(newParticles);
  }, []);

  const scrollToBooking = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('agendar');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="pt-32 pb-24 relative overflow-hidden mesh-warm min-h-[90vh] flex items-center">
      {/* Background Particle Animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {particles.map((p) => (
          <div 
            key={p.id}
            className="particle"
            style={{
              width: `${p.size}px`,
              height: `${p.size}px`,
              left: p.left,
              top: p.top,
              animationDuration: p.duration,
              animationDelay: p.delay
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-orange-100 text-orange-700 text-xs font-black uppercase tracking-widest border border-orange-200 mb-10 animate-bounce">
          <Sparkles size={14} /> 
          RESULTADOS GARANTIZADOS • COLOMBIA
        </div>
        
        <h1 className="text-5xl md:text-8xl lg:text-9xl font-black text-slate-900 tracking-tighter leading-[0.9] mb-8">
          ROI de 3x en 90 días <br/>
          <span className="bg-gradient-to-r from-orange-600 via-amber-500 to-orange-600 bg-clip-text text-transparent italic">o trabajamos gratis.</span>
        </h1>
        
        <p className="max-w-3xl mx-auto text-xl md:text-2xl text-slate-600/80 leading-relaxed font-medium mb-16">
          Triplicamos la facturación de empresas colombianas con pauta publicitaria de alto impacto. Si no alcanzamos el <span className="text-orange-600 font-black">objetivo de 3x</span> en 3 meses, operamos tu cuenta sin honorarios.
        </p>

        {/* Enhanced VSL Container with Multi-Gradients */}
        <div className="max-w-5xl mx-auto mb-20 relative">
          {/* Colorful Gradient Blobs behind VSL */}
          <div className="absolute -top-20 -left-20 w-80 h-80 bg-orange-400/30 rounded-full blur-[100px]"></div>
          <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-amber-400/30 rounded-full blur-[100px]"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gradient-to-r from-orange-100 via-white to-amber-100 opacity-30 blur-3xl -z-10"></div>

          <div className="aspect-video bg-slate-950 rounded-[3rem] overflow-hidden shadow-[0_50px_100px_-20px_rgba(234,88,12,0.3)] relative border-[1px] border-orange-200/50 group cursor-pointer ring-8 ring-white/50">
            <img 
              src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&q=80&w=1200" 
              alt="Delta Growth Hub" 
              className="absolute inset-0 w-full h-full object-cover opacity-50 grayscale hover:grayscale-0 transition-all duration-1000 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-orange-950/40 via-transparent to-transparent"></div>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-8">
              <div className="relative group">
                <div className="absolute -inset-4 bg-orange-600 rounded-full blur-2xl opacity-40 group-hover:opacity-80 transition-opacity"></div>
                <div className="w-28 h-28 bg-orange-600 rounded-full flex items-center justify-center text-white shadow-2xl relative z-10 hover:scale-110 transition-transform active:scale-95">
                  <Play fill="currentColor" size={40} className="ml-2" />
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-2xl px-10 py-4 rounded-full border border-white/20 shadow-2xl">
                <p className="text-white font-black tracking-[0.2em] uppercase text-xs">Video Estratégico Delta 2024</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
          <button 
            onClick={scrollToBooking}
            className="w-full sm:w-auto px-14 py-6 bg-orange-600 text-white rounded-[2rem] text-2xl font-black hover:bg-orange-700 transition-all shadow-[0_20px_50px_-10px_rgba(234,88,12,0.4)] flex items-center justify-center gap-4 active:scale-95 group"
          >
            Escalar Mi Negocio Ahora <ArrowRight className="group-hover:translate-x-2 transition-transform" />
          </button>
          <div className="flex flex-col items-center sm:items-start">
            <div className="flex -space-x-3 mb-2">
              {[1,2,3,4,5].map(i => (
                <div key={i} className="w-12 h-12 rounded-full border-4 border-white bg-orange-100 shadow-xl overflow-hidden ring-1 ring-orange-50">
                   <img src={`https://i.pravatar.cc/100?u=delta${i}`} alt="Client" />
                </div>
              ))}
            </div>
            <p className="text-orange-900/60 text-[10px] font-black uppercase tracking-[0.2em]">Partner de +150 CEOs en Colombia</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
