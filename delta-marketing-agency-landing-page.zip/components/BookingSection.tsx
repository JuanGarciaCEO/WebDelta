
import React from 'react';
import { Target, TrendingUp, CheckCircle2, Calendar } from 'lucide-react';

const BookingSection: React.FC = () => {
  return (
    <section id="agendar" className="py-32 bg-[#fffaf5] scroll-mt-header relative overflow-hidden">
      {/* Decorative Orbs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-100 rounded-full blur-[100px] -z-10 opacity-50"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 text-orange-600 font-black text-xs uppercase tracking-[0.3em] mb-4">
            <Calendar size={14} /> AGENDA ABIERTA
          </div>
          <h2 className="text-4xl md:text-7xl font-black text-slate-900 mb-8 tracking-tighter leading-[0.9]">
            Hablemos de tus próximos 90 días.
          </h2>
          <p className="text-xl text-slate-500 leading-relaxed font-medium">
            Sin compromisos. Analizaremos tu ecosistema actual y te daremos el plan técnico exacto para alcanzar el ROI de 3x con nuestra garantía.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          {/* Side Info */}
          <div className="lg:col-span-4 space-y-8">
            <div className="bg-white p-12 rounded-[3.5rem] border border-orange-50 shadow-[0_30px_60px_-15px_rgba(234,88,12,0.05)]">
              <h4 className="font-black text-slate-900 text-xl mb-10 flex items-center gap-3">
                <Target className="text-orange-600" size={24} /> 
                ¿Qué obtendrás?
              </h4>
              <ul className="space-y-10">
                {[
                  { t: "Auditoría de Activos", d: "Revisamos tus anuncios y funnels actuales." },
                  { t: "Cálculo de Escala", d: "Proyectamos tu ROI potencial real." },
                  { t: "Activación de Garantía", d: "Cómo firmamos tu 3x ROI en 90 días." }
                ].map((item, i) => (
                  <li key={i} className="flex gap-5">
                    <div className="shrink-0 w-10 h-10 rounded-2xl bg-orange-50 flex items-center justify-center text-orange-600 font-black text-base shadow-sm">
                      {i + 1}
                    </div>
                    <div>
                      <p className="font-black text-slate-900 text-lg mb-1 tracking-tight">{item.t}</p>
                      <p className="text-slate-500 text-sm leading-relaxed font-medium">{item.d}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-orange-600 p-12 rounded-[3.5rem] text-white shadow-3xl shadow-orange-600/40 relative overflow-hidden group">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-125 transition-transform duration-700">
                 <TrendingUp size={120} />
              </div>
              <h4 className="text-2xl font-black mb-4 tracking-tight">Compromiso Delta</h4>
              <p className="text-orange-50/70 text-sm leading-relaxed mb-8 font-medium">
                Solo aceptamos 2 marcas nuevas por mes en Colombia para asegurar que el 3x ROI sea una realidad operativa, no solo una promesa.
              </p>
              <div className="flex items-center gap-3 text-white text-xs font-black uppercase tracking-widest bg-white/10 p-3 rounded-2xl border border-white/20">
                <CheckCircle2 size={16} /> Auditoría Gratis • Cupos Limitados
              </div>
            </div>
          </div>

          {/* Calendly Widget */}
          <div className="lg:col-span-8 bg-white rounded-[3.5rem] shadow-[0_50px_100px_-20px_rgba(234,88,12,0.15)] overflow-hidden border border-orange-100 ring-8 ring-white/50">
            <div className="p-6 bg-slate-900 text-white text-center">
              <span className="text-xs font-black uppercase tracking-[0.3em] text-orange-400">CALENDARIO OFICIAL • DELTA COLOMBIA</span>
            </div>
            {/* Calendly inline widget */}
            <div 
              className="calendly-inline-widget" 
              data-url="https://calendly.com/juangarciaceo-chispadigitalx/30min" 
              style={{ minWidth: '320px', height: '700px' }}
            ></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BookingSection;
