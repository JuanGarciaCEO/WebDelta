
import React from 'react';
import { Play, CheckCircle2 } from 'lucide-react';

const VSLSection: React.FC = () => {
  return (
    <section id="vsl" className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mb-6 leading-tight">
              ¿Harto de agencias que solo te prometen "Alcance" y "Engagement"?
            </h2>
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              La mayoría de las agencias se esconden detrás de métricas de vanidad porque no saben cómo generar ventas reales. Nosotros eliminamos el riesgo por completo con nuestro sistema de escala Delta.
            </p>
            
            <ul className="space-y-4 mb-10">
              {[
                "Resolvemos el problema de la captación de leads cualificados.",
                "Estructuramos ofertas irresistibles que el mercado no puede ignorar.",
                "Instalamos un sistema de ventas automático en tu negocio.",
                "Garantizamos resultados por contrato: o escalas, o no pagas."
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle2 className="text-blue-600 shrink-0 mt-1" size={20} />
                  <span className="text-slate-800 font-medium">{item}</span>
                </li>
              ))}
            </ul>

            <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm italic text-slate-600 border-l-4 border-l-blue-600">
              "No necesitamos más visibilidad, necesitamos más facturación. Delta fue la única agencia que puso su dinero donde estaba su boca."
              <p className="mt-2 font-bold text-slate-900 not-italic">— Marco Rivera, CEO de ScaleFlow</p>
            </div>
          </div>

          <div className="relative group">
            {/* Video Placeholder Container */}
            <div className="aspect-video bg-slate-900 rounded-3xl overflow-hidden shadow-2xl relative flex items-center justify-center border-4 border-white">
              <img 
                src="https://picsum.photos/seed/delta/1200/675" 
                alt="Video Thumbnail" 
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-110 transition-transform duration-700"
              />
              <div className="relative z-10 flex flex-col items-center gap-4 cursor-pointer">
                <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-xl group-hover:bg-blue-500 transition-colors animate-pulse">
                  <Play fill="currentColor" size={32} className="ml-1" />
                </div>
                <span className="bg-slate-900/80 backdrop-blur px-4 py-2 rounded-full text-white text-sm font-bold uppercase tracking-widest border border-white/20">
                  Ver Video Estratégico (12 min)
                </span>
              </div>
            </div>
            
            {/* Visual Accents */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-blue-600/10 rounded-full blur-xl -z-10"></div>
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-indigo-600/10 rounded-full blur-xl -z-10"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VSLSection;
