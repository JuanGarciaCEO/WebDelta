
import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToBooking = (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById('agendar');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/60 backdrop-blur-xl border-b border-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 md:h-20">
          {/* Refined Minimalist Logo */}
          <div className="flex items-center gap-2 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
            <div className="relative">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-orange-600 transition-transform group-hover:rotate-12">
                <path d="M12 3L2 21H22L12 3Z" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <div className="absolute inset-0 bg-orange-400 blur-lg opacity-20 group-hover:opacity-40 transition-opacity"></div>
            </div>
            <span className="text-xl font-extrabold tracking-tighter text-slate-900">DELTA</span>
          </div>

          <nav className="hidden md:flex items-center gap-10">
            <a href="#beneficios" className="text-sm font-bold text-slate-500 hover:text-orange-600 transition-colors">Estrategia</a>
            <a href="#oferta" className="text-sm font-bold text-slate-500 hover:text-orange-600 transition-colors">Garantía</a>
            <button 
              onClick={scrollToBooking}
              className="bg-orange-600 text-white px-7 py-3 rounded-full text-sm font-black hover:bg-orange-700 transition-all shadow-xl shadow-orange-200 active:scale-95"
            >
              Agendar Auditoría
            </button>
          </nav>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 p-2">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-2xl border-b border-orange-100 p-8 space-y-6 shadow-2xl">
          <a href="#beneficios" onClick={() => setIsOpen(false)} className="block text-xl font-black text-slate-900">Estrategia</a>
          <a href="#oferta" onClick={() => setIsOpen(false)} className="block text-xl font-black text-slate-900">Garantía</a>
          <button 
            onClick={(e) => { setIsOpen(false); scrollToBooking(e); }}
            className="w-full bg-orange-600 text-white py-5 rounded-3xl font-black text-center text-lg"
          >
            Agendar Auditoría
          </button>
        </div>
      )}
    </header>
  );
};

export default Header;
